# echo "setup Root v0 in /afs/ihep.ac.cn/users/w/wanghh/scratchfs_dir/soft_test/offline/Rootinit"

if test "${CMTROOT}" = ""; then
  CMTROOT=/scratchfs/bes/wanghh/soft_test/ExternalLibs/CMT/v1r26; export CMTROOT
fi
. ${CMTROOT}/mgr/setup.sh
cmtRoottempfile=`${CMTROOT}/mgr/cmt -quiet build temporary_name`
if test ! $? = 0 ; then cmtRoottempfile=/tmp/cmt.$$; fi
${CMTROOT}/mgr/cmt setup -sh -pack=Root -version=v0 -path=/afs/ihep.ac.cn/users/w/wanghh/scratchfs_dir/soft_test/offline/Rootinit  -no_cleanup $* >${cmtRoottempfile}
if test $? != 0 ; then
  echo >&2 "${CMTROOT}/mgr/cmt setup -sh -pack=Root -version=v0 -path=/afs/ihep.ac.cn/users/w/wanghh/scratchfs_dir/soft_test/offline/Rootinit  -no_cleanup $* >${cmtRoottempfile}"
  cmtsetupstatus=2
  /bin/rm -f ${cmtRoottempfile}
  unset cmtRoottempfile
  return $cmtsetupstatus
fi
cmtsetupstatus=0
. ${cmtRoottempfile}
if test $? != 0 ; then
  cmtsetupstatus=2
fi
/bin/rm -f ${cmtRoottempfile}
unset cmtRoottempfile
return $cmtsetupstatus

